function submitForm() {
    var form = document.getElementById("contactForm");
    var message = "Thanks for contacting us! We will be in touch with you shortly.";
    var button = form.querySelector("button");
    button.innerText = "Sending";
    setTimeout(function() {

        form.reset();
        form.innerHTML = "<p>" + message + "</p>";
    }, 2000);
}