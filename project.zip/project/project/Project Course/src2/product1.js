export const productsData = [
    {
        id: 13,
        title: "Green Hoodie",
        gender: "Men",
        price: '150.00',
        image: 'image/Men/product-hoodie3-400x400.jpg'
    },
    {
        id: 14,
        title: "Red Hoodie",
        gender: "Men",
        price: '150.00',
        image: 'image/Men/product-hoodie4.jpg-400x400.jpg'
    }
];
