export const productsData = [
    {
        id: 25,
        title: "Green Hoodie",
        gender: "Men",
        price: '150.00',
        image: './image/Everthing/product-hoodie3-400x400.jpg'
    },
    {
        id: 26,
        title: "Lemons Tshirt",
        gender: "Women",
        price: '25.00 – 28.00',
        image: 'image/Everthing/tshirt4-300x300.jpg'
    },
    {
        id: 27,
        title: "Light Brown Purse",
        gender: "Accessories",
        price: '150.00',
        image: 'image/Everthing/product-bag1-400x400.jpg'
    },
    {
        id: 28,
        title: "Purple Tshirt",
        gender: "Women",
        price: '25.00 – 27.00',
        image: 'image/Everthing/tshirt1-400x400.jpg'
    },
    {
        id: 29,
        title: "Red Hoodie",
        gender: "Men",
        price: '150.00',
        image: 'image/Everthing/product-hoodie4.jpg-400x400.jpg'
    },
    {
        id: 30,
        title: "Slim Fit Blue Jeans",
        gender: "Women",
        price: '150.00',
        image: 'image/Everthing/product-w-jeans3-400x400.jpg'
    },
    {
        id: 31,
        title: "White Underground Tshirt",
        gender: "Women",
        price: '150.00',
        image: 'image/Everthing/tshirt4-300x300.jpg'
    }
    
];
