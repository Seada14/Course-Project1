export const productsData = [
    {
       id: 1 ,
       title : "Anchor Bracelet",
       gender:"Accessories",
       price: '150.00 - 180.00',
       image: './image/Everthing/product-accessory2-400x400.jpg'
    },
    {
       id: 2 ,
       title : "Basic Gray Jeans",
       gender:"Women",
       price: '150.00',
       image: './image/Everthing/product-w-jeans4-400x400.jpg'
    },
    {
       id: 3 ,
       title : "Black Hoodie",
       gender:"Men",
       price: '150.00',
       image: './image/Everthing/product-hoodie1-400x400.jpg'
    },
    {
       id: 4 ,
       title : "Black Over-the-shoulder Handbag",
       gender:"Accessories",
       price: '150.00',
       image: './image/Everthing/product-bag2-400x400.jpg'
    },
    {
       id: 5 ,
       title : "Blue Denim Jeans",
       gender:"Women",
       price: '150.00',
       image: './image/Everthing/product-w-jeans2-400x400.jpg'
    },
    {
       id: 6 ,
       title : "Blue Denim Shorts",
       gender:"Women",
       price: '130.00',
       image: './image/Everthing/product-w-jeans1-400x400.jpg'
    },
    {
       id: 7 ,
       title : "Blue Hoodie",
       gender:"Men",
       price: '150.00',
       image: './image/Everthing/product-hoodie2-400x400.jpg'
    },
    {
       id: 8 ,
       title : "Blue Tshirt",
       gender:"Men",
       price: '40.00',
       image: './image/Everthing/tshirt2-300x300.jpg'
    },
    {
       id: 9 ,
       title : "Boho Bangle Bracelet",
       gender:"Accessories",
       price: '150.00 - 170.00',
       image: './image/Everthing/product-accessory1-400x400.jpg'
    },
    {
       id: 10 ,
       title : "Bright Red BagBright Gold Purse With Chain",
       gender:"Accessories",
       price: '150.00',
       image: './image/Everthing/product-bag4-400x400.jpg'
    },
    {
        id: 11 ,
        title : "Bright Red Bag",
        gender:"Accessories",
        price: '100.00 - 140.00',
        image: './image/Everthing/product-bag3-400x400.jpg'
     },
     {
        id: 12 ,
        title : "Buddha Bracelet",
        gender:"Accessories",
        price: '150.00',
        image: './image/Everthing/product-accessory3-400x400.jpg'
     },
]