export const productsData = [
    {
        id: 13,
        title: "Lemons Tshirt",
        gender: "Women",
        price: '25.00 - 28.00',
        image: 'image/Woman/tshirt4-400x400.jpg'
    },
    {
        id: 14,
        title: "Light Brown Purse",
        gender: "Accessories",
        price: '150.00',
        image: 'image/Woman/product-bag1-400x400.jpg'
    },
    {
        id: 15,
        title: "Purple Tshirt",
        gender: "Women",
        price: '25.00 - 27.00',
        image: 'image/Woman/tshirt1.jpg'
    },
    {
        id: 16,
        title: "Slim Fit Blue Jeans",
        gender: "Women",
        price: '150.00',
        image: 'image/Woman/product-w-jeans3-400x400.jpg'
    },
    {
        id: 17,
        title: "White Underground Tshirt",
        gender: "Women",
        price: '150.00',
        image: 'image/Woman/tshirt4-400x400.jpg'
    }
    
];
