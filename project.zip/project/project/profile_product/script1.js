document.addEventListener('DOMContentLoaded', function () {
    const descriptionLink = document.querySelector('.desc');
    const reviewLink = document.querySelector('.review');
    const descriptionSection = document.getElementById('descriptionSection');
    const reviewsSection = document.getElementById('reviewsSection');
    const bord1 = document.getElementById('bord1');
    const bord2 = document.getElementById('bord2');

    // Initial setup: Show description, hide reviews, and apply border to description link
    descriptionLink.classList.add('active');
    descriptionSection.style.display = 'block';
    reviewsSection.style.display = 'none';

    // Event listeners to toggle between Description and Reviews
    descriptionLink.addEventListener('click', function () {
        descriptionSection.style.display = 'block';
        reviewsSection.style.display = 'none';
        descriptionLink.classList.add('active');
        reviewLink.classList.remove('active');
    });

    reviewLink.addEventListener('click', function () {
        descriptionSection.style.display = 'none';
        reviewsSection.style.display = 'block';
        descriptionLink.classList.remove('active');
        reviewLink.classList.add('active');
    });
});



