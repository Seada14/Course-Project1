export const productsData = [
    {
       id: 1 ,
       title : "DNK Yellow Shoes",
       gender:"Men",
       price: '120.00',
       image: './image/products/sports-shoe3-600x600.jpg'
    },
    {
       id: 2 ,
       title : "DNK Blue Shoes",
       gender:"Men",
       price: '200',
       image: './image/products/sports-shoe1-600x600.jpg'
    },
    {
       id: 3 ,
       title : "Dark Brown Jeans",
       gender:"Men",
       price: '150',
       image: './image/products/product-m-jeans1-600x600.jpg'
    },
    {
       id: 4 ,
       title : "Blue Denim Jeans",
       gender:"Women",
       price: '150',
       image: './image/products/product-w-jeans2-600x600.jpg'
    },
    {
       id: 5 ,
       title : "Basic Gray Jeans",
       gender:"Women",
       price: '150',
       image: './image/products/product-w-jeans4-600x600.jpg'
    },
    {
       id: 6 ,
       title : "Blue Denim Shorts",
       gender:"Women",
       price: '130',
       image: './image/products/denim.jpg'
    },
    {
       id: 7 ,
       title : "Anchor Bracelet",
       gender:"Accessories",
       price: '150 - 180',
       image: './image/products/product-accessory2-600x600.jpg'
    },
    {
       id: 8 ,
       title : "Boho Bangle Bracelet",
       gender:"Accessories",
       price: '150 - 170',
       image: './image/products/product-accessory1-600x600.jpg'
    },
    {
       id: 9 ,
       title : "Light Brown Purse",
       gender:"Accessories",
       price: '150',
       image: './image/products/product-bag1-600x600.jpg'
    },
    {
       id: 10 ,
       title : "Bright Red Bag",
       gender:"Accessories",
       price: '100 - 140',
       image: './image/products/product-bag3-600x600.jpg'
    },
]
